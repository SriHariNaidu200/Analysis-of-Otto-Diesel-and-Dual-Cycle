# Otto-cycle-and-Diesel-cycle-Analysis---MatLab
Calculated efficiency, torque, net-work output, compression ratio, cutoff ratio and mean effective pressure and Plotted P-V diagrams, Thermal efficiency vs compression ratio, Thermal efficiency vs cut-off ratio and stroke vs efficiency graphs.
